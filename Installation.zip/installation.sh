#!/bin/bash

echo "             ____________________________________________________"
echo "            /                                                    \ "
echo "           |    _____________________________________________     |"
echo "           |   |                                             |    |"
echo "           |   |  C:\> _                                     |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |                                             |    |"
echo "           |   |_____________________________________________|    |"
echo "           |                                                      |"
echo "            \_____________________________________________________/"
echo "                   \_______________________________________/"
echo "                _______________________________________________"
echo "             _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- -_"
echo "          _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.-_"
echo "       _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-__. .-.-.-.-_"
echo "    _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.-_"
echo " _-'.-.-.-.-.-. .---.-. .-----------------------------. .-.---. .---.-.-.-.-_"
echo ":-----------------------------------------------------------------------------:"
echo "---._.-----------------------------------------------------------------._.---"
echo "   "



echo "_________________________________________________"
echo "   _____        __ _                          "
echo "  / ____|      / _| |                         "
echo " | (___   ___ | |_| |___      ____ _ _ __ ___ "
echo "  \___ \ / _ \|  _| __\ \ /\ / / _ | '__/ _ \ "
echo "  ____) | (_) | | | |_ \ V  V / (_| | | |  __/ "
echo " |_____/ \___/|_|  \__| \_/\_/ \__,_|_|  \___| "
echo "_________________________________________________"                                              
                                              



# Install Visual Studio Code on Ubuntu
sudo apt-get update -y
sudo apt-get upgrade -y
echo "Installing Visual Studio Code"
wget -q https://packages.microsoft.com/keys/microsoft.asc -O- | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://packages.microsoft.com/repos/vscode stable main"
sudo apt update
sudo apt upgrade
sudo apt install code
sudo apt-get install build-essential gdb


# Install google chrome
echo "Installing Google Chrome"
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb

# If there are any missing dependencies, use the following command to fix them
sudo apt --fix-broken install

#Install chromium in case thta google chrome is not supported
sudo apt install chromium-browser



# Define the script content
SCRIPT_CONTENT="#!/bin/bash\n\ncode --install-extension ms-vscode.cpptools\ncode --install-extension aaron-bond.better-comments\ncode --install-extension ritwickdey.LiveServer\ncode --install-extension donjayamanne.githistory"
# Define the script path
SCRIPT_PATH="/etc/profile.d/vscode.sh"
# Create the script file
echo -e "$SCRIPT_CONTENT" | sudo tee "$SCRIPT_PATH" > /dev/null
# Make the script executable
sudo chmod +x "$SCRIPT_PATH"
echo "Installation script created at $SCRIPT_PATH and set to execute on login."



echo "_________________________________"
echo " _    _                   "
echo " | |  | |                  "
echo " | |  | |___  ___ _ __ ___ "
echo " | |  | / __|/ _ \ '__/ __|"
echo " | |__| \__ \  __/ |  \__ \ "
echo "  \____/|___/\___|_|  |___/"
echo "_________________________________"                           

# Check if the file exists
if [ ! -f "nanti.csv" ]; then
  echo "Error: File 'nanti.csv' not found."
  exit 1
fi

# Create the required directories and files in the skel directory
skel_directory="/etc/skel"
sudo mkdir -p "$skel_directory/Documents"
sudo mkdir -p "$skel_directory/Projets"
sudo mkdir -p "$skel_directory/Téléchargements"

# Create some example files in the directories
sudo touch "$skel_directory/Documents/example_document.txt"
sudo touch "$skel_directory/Projets/example_project.txt"
sudo touch "$skel_directory/Téléchargements/example_download.txt"


# Check if the group 'Chief' exists, if not, create it
if ! grep -q "Chief" /etc/group; then
  echo "Creating group: Chief"
  sudo groupadd "Chief"
fi

# Create shared folders for Chief and All
shared_folder_chief="/home/sharedFolderForChief"
shared_folder_all="/home/sharedFolderForAll"
sudo mkdir -p "$shared_folder_chief"
sudo mkdir -p "$shared_folder_all"
sudo chmod 770 "$shared_folder_chief"
sudo chmod 777 "$shared_folder_all"

# Read the CSV file line by line with -r to not interpret any backslash characters
while IFS=';' read -r forename name password department; do
  # Remove spaces from the name and create a username by taking the first letter of the forename and appending the modified last name
  username="${forename:0:1}${name// /}"

  # Ensure the username is at most 8 characters long
  if [ ${#username} -gt 8 ]; then
    username="${username:0:8}"
  fi

  # Convert the entire username to lowercase
  username=$(echo "$username" | tr '[:upper:]' '[:lower:]')

  # Trim whitespaces from the department field
  department=$(echo "$department" | tr -d '[:space:]')

  # Check if the user already exists
  count=1
  while id "$username" &>/dev/null; do
    # If the user exists, append a number to the username
    username="${username:0:6}$(printf "%02d" $count)"
    ((count++))
  done
  # Create a shared folder for the department
  shared_folder_department="/home/$department/sharedFolder"
  # Check if the group with the department already exists, if not, create it
  isNewDepartment=0
  if [ -n "$department" ] && ! grep -q "$department:" /etc/group; then
    echo "Creating group: $department"
    sudo groupadd "$department"
    isNewDepartment=1
    echo "Creating shared folder: $shared_folder_department"
    sudo mkdir -p "$shared_folder_department"
    sudo chown ":$department" "$shared_folder_department"
    sudo chmod 770 "$shared_folder_department"
  fi
  
  # Display information and create user with the specified password and add to the group
  echo "Creating user: $username with password: $password and adding to group: $department"
  sudo useradd -m -k "$skel_directory" -p "$(openssl passwd -1 "$password")" -G "$department" "$username"

  # If a new department was created, add the user to the 'Chief' group
  if [ $isNewDepartment -eq 1 ]; then
    echo "Adding $username to Chief"
    sudo usermod -a -G Chief "$username"
    sudo ln -s "$shared_folder_chief" "/home/$username/SharedFolderChief"
  fi

# Create shortcuts for shared folders in the user's home directory
echo "Creating shortcuts for $username"
sudo ln -s "$shared_folder_department" "/home/$username/SharedFolder"
sudo ln -s "$shared_folder_all" "/home/$username/SharedFolderForAll"


done < "nanti.csv"

# Add Chief to sharedFolderForChief
echo "Adding Chief to sharedFolderForChief"
sudo chown :Chief "$shared_folder_chief"

